# smart-restaurant-app-backend

Smart Restaurant App Research and Development Project 2023-24/Autumn

# create config.env file

DB_PASSWORD=xyz
DB_USERNAME=xyz
DB_URL=xyz
PORT=8000
NODE_ENV=development
JWT_SECRET=xyz
REACT_APP_URL=http:xyz
